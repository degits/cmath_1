String getReloadingString() {
//Paste your question here
return """
->q 22
->img <url>https://images.unsplash.com/photo-1644301467387-d85f3ca1e6a9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=10</url> <width>100</width> <height>50</height>
->sub-part (a)
<m>f(x)=x^{2}+p x+c</m> <m>m+c</m> <b>පොදු</b> මූලයක් ඇති බව දී ඇත.

""";
}
